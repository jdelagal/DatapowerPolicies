"use strict";

var urlopen = require ('urlopen');


// define the urlopen options
var options = {
    target: 'http://192.168.99.1:8089/archibus/cxf/ReservesRm',
    //target: 'http://127.0.0.1:1880/fire',
    //target: 'https://www.elmunssd.es/',
    //target: 'https://santanderconsumersandbox.eu-gb.mybluemix.net/fire', 
    // if target is https, supply a sslClientProfile
    // target: 'https://127.0.0.1:42409/echo',
    // sslClientProfile: 'alice-sslClient',
    //sslClientProfile : 'webapi-sslcli-mgmt',
    method: 'get',
    headers: { 'X-My-Header1' : 'value1', 'X-My-Header2' : 'value2' },
    contentType: 'application/json',
    timeout: 60,
    data: "Hello DataPower GatewayScript",
};

function callAudit(opt, url)
{
        // open connection to target and send data over
        url.open (opt, function (error, response) {
            if (error) {
                // an error occurred during request sending or response header parsing
                session.output.write ("urlopen connect error: " + JSON.stringify(error));
            } else {
                // read response data
                // get the response status code
                var responseStatusCode = response.statusCode;
                if (responseStatusCode == 200) {
                    response.readAsBuffer(function(error, responseData) {
                        if (error) {
                            // error while reading response or transferring data to Buffer
                            session.output.write("readAsBuffer error: " + JSON.stringify(error));
                        } else {
                            session.output.write(responseData);
                        } 
                    });
                } else {
                    session.output.write ("urlopen target return statusCode " + responseStatusCode);
                }
            }
        }); // end of urlopen.open()
}
var respuesta = callAudit(options, urlopen);
console.log('COMPLETED ?');
//https://www.todojs.com/controlar-la-ejecucion-asincrona/
//http://www.orangespecs.com/datapower-rest-api-walkthrough/
//https://library.roguewave.com/pages/viewpage.action?pageId=5276740
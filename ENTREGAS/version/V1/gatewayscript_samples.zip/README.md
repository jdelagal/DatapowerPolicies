# DataPower GatewayScript Examples

example-b2b-routing.js
example-console.js
example-context.js
example-contextvars.js
example-error.js
example-ext-func-dp-gwscript.js
example-ext-func-dp-gwscript.xsl
example-file-urlopen.js
example-header.js
example-healthcheck.js
example-jwe-encrypt-decrypt.js
example-jws-sign-verify.js
example-jwt-create.js
example-jwt-validate.js
example-script-defaults.js
example-servicevars.js
example-urlopen-mq.js
example-urlopen.js
example-xml-dom.js
example-xml-xpath.js
example-xml-xslt.js


## Contributing

If you want to contribute to the project, you will need to fill in the appropriate Contributor License agreement which can be found under the CLA directory. Follow the directions inside the document so that any submissions can be properly accepted into the repository.

## Authors

* IBM

For more open-source projects from IBM, head over [here](http://ibm.github.io).

## Copyright and license

Copyright 2015 IBM Corp. under [the Apache 2.0 license](https://www.apache.org/licenses/LICENSE-2.0).

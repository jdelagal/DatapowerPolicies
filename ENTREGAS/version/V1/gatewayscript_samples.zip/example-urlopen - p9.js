"use strict";

var http = require('http');
message.body = { text : 'Hello World' };
console.log('COMPLETED ?');
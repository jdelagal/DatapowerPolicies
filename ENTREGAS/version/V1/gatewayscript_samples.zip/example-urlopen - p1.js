//Here we create the promise
function httpCall(url){
  return new Promise(function(resolve, reject){
    //create request object
    var request = new XMLHttpRequest();

    //callback to call when readyState changes
    request.onreadystatechange = function(){
      //check status when operation is completed
      if(request.readyState == 4){
        //if GET request is resolved with code 200, resolve promise
        if(request.status === 200){
          resolve(request.response);
        }
        //otherwise, reject promise
        else{
          reject(new Error(request.statusText));
        }
      }
    };

    //callback to call when error is received: reject promise
    request.onerror = function(){
      reject(new Error(this.statusText));
    };

    //initialize as GET request and set url
    request.open('GET', url);

    //send http get request
    request.send();
  });
};

//Here, we add callbacks
httpGET('http://192.168.99.1:8089/archibus/cxf/ReservesRm').then(function(value){
  console.log("success");
}, function(reason){
  console.log("error ", reason);
});
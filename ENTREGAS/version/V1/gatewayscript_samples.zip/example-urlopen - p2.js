var urlopen = require ('urlopen');


// define the urlopen options
var options = {
    //target: 'http://192.168.99.1:8089/archibus/cxf/ReservesRm',
    //target: 'https://www.elmunssd.es/',
    target: 'https://santanderconsumersandbox.eu-gb.mybluemix.net/fire', 
    // if target is https, supply a sslClientProfile
    // target: 'https://127.0.0.1:42409/echo',
    // sslClientProfile: 'alice-sslClient',
    sslClientProfile : 'webapi-sslcli-mgmt',
    method: 'get',
    headers: { 'X-My-Header1' : 'value1', 'X-My-Header2' : 'value2' },
    contentType: 'application/json',
    timeout: 60,
    data: "Hello DataPower GatewayScript",
};

function callAudit(opt)
{
    var promise = new Promise(function(resolve, reject) {
        // open connection to target and send data over
        urlopen.open (opt, function (error, response) {
            if (error) {
                reject(err);
                return;
            } else {
                resolve(response.disconnect());
                //resolve(response);
            }
        }); // end of urlopen.open()
    });
    
    return promise;
}

var promise = callAudit(options);
promise.then(
    function(response) {
        console.log("ok");
    },
    function(err) {
        console.log("ko");
    }
);
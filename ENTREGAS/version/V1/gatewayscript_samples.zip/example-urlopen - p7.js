"use strict";

var urlopen = require ('urlopen');


var options = {
    target: 'http://192.168.99.1:8089/archibus/cxf/ReservesRm',
    //target: 'https://www.elmunssd.es/',
    //target: 'https://santanderconsumersandbox.eu-gb.mybluemix.net/fire', 
    // if target is https, supply a sslClientProfile
    // target: 'https://127.0.0.1:42409/echo',
    // sslClientProfile: 'alice-sslClient',
    //sslClientProfile : 'webapi-sslcli-mgmt',
    method: 'get',
    headers: { 'X-My-Header1' : 'value1', 'X-My-Header2' : 'value2' },
    contentType: 'application/json',
    timeout: 60,
    data: "Hello DataPower GatewayScript",
};

function callAudit(opt, urlAudit)
{
        // open connection to target and send data over
        urlAudit.open (opt, function (error, response) {
            if (error) {
                // an error occurred during request sending or response header parsing
                session.output.write ("urlopen connect error: " + JSON.stringify(error));
            } else {
                // read response data
                // get the response status code
                var responseStatusCode = response.statusCode;
                if (responseStatusCode == 200) {
                    response.readAsBuffer(function(error, responseData) {
                        if (error) {
                            // error while reading response or transferring data to Buffer
                            session.output.write("readAsBuffer error: " + JSON.stringify(error));
                        } else {
                            session.output.write(responseData);
                        } 
                    });
                } else {
                    session.output.write ("urlopen target return statusCode " + responseStatusCode);
                }
            }
        }); // end of urlopen.open()
}

function asyncAudit(opt, urlAudit, callAudit) {
    console.log('START execution with opt =', opt);
    callAudit(opt, urlAudit);
    setTimeout(function() {

    }, 5000);
    callAudit(opt, urlAudit);
}

asyncAudit(options, urlopen, function(options) {
    console.log('END execution with options =', options);
});
console.log('COMPLETED ?');
/* 
var promise = callAudit(options);
promise.then(
    function(response) {
        console.log("ok");
    },
    function(err) {
        console.log("ko");
    }
);
*/